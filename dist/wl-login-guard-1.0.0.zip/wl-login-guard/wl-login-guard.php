<?php
/**
 * Plugin Name:       WL Login Guard
 * Plugin URI:        https://wisionarylab.com/
 * Description:       Troca o endereço de login do WordPress (padrão: /wl-admin) e esconde wp-login.php e /wp-admin de quem não está logado.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Wisionary Lab
 * Author URI:        https://wisionarylab.com/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       wl-login-guard
 *
 * Emergência: defina WL_LOGIN_GUARD_DISABLE como true no wp-config.php para
 * desligar o plugin, ou WL_LOGIN_SLUG para forçar um endereço de login.
 */

defined( 'ABSPATH' ) || exit;

final class WL_Login_Guard {

	const VERSION      = '1.0.0';
	const OPTION       = 'wl_login_guard_slug';
	const DEFAULT_SLUG = 'wl-admin';

	/** Endereços que não podem virar o login. */
	const RESERVED = array( 'wp-admin', 'wp-login', 'wp-login.php', 'admin', 'login', 'dashboard', 'wp-content', 'wp-includes', 'wp-json', 'feed' );

	/** A requisição tentou abrir wp-login.php (ou wp-register/wp-signup) diretamente. */
	private $blocked_login_file = false;

	public function __construct() {
		add_action( 'plugins_loaded', array( $this, 'route_request' ), 9999 );
		add_action( 'wp_loaded', array( $this, 'handle_request' ) );

		add_filter( 'site_url', array( $this, 'filter_site_url' ), 10, 4 );
		add_filter( 'network_site_url', array( $this, 'filter_network_site_url' ), 10, 3 );
		add_filter( 'wp_redirect', array( $this, 'filter_wp_redirect' ), 10, 2 );
		add_filter( 'login_url', array( $this, 'filter_login_url' ), 10, 3 );

		// O WordPress redireciona /login, /admin e /dashboard para o login padrão. Isso entregaria o endereço.
		remove_action( 'template_redirect', 'wp_redirect_admin_locations', 1000 );

		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_notices', array( $this, 'admin_notices' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), array( $this, 'action_links' ) );
	}

	/* ------------------------------------------------------------------ */
	/* Endereço de login                                                   */
	/* ------------------------------------------------------------------ */

	public static function slug() {
		if ( defined( 'WL_LOGIN_SLUG' ) && WL_LOGIN_SLUG ) {
			$slug = sanitize_title( WL_LOGIN_SLUG );
		} else {
			$slug = sanitize_title( (string) get_option( self::OPTION, self::DEFAULT_SLUG ) );
		}
		return ( '' === $slug || in_array( $slug, self::RESERVED, true ) ) ? self::DEFAULT_SLUG : $slug;
	}

	private function uses_permalinks() {
		return (bool) get_option( 'permalink_structure' );
	}

	public function login_url( $scheme = null ) {
		$home = home_url( '/', $scheme );
		if ( $this->uses_permalinks() ) {
			return user_trailingslashit( $home . self::slug() );
		}
		return $home . '?' . self::slug();
	}

	private function request_path() {
		$path = (string) wp_parse_url( rawurldecode( $_SERVER['REQUEST_URI'] ?? '' ), PHP_URL_PATH ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		return untrailingslashit( $path );
	}

	/* ------------------------------------------------------------------ */
	/* Roteamento                                                          */
	/* ------------------------------------------------------------------ */

	public function route_request() {
		global $pagenow;

		$path = $this->request_path();

		// Formulário de post protegido por senha: deixa o WordPress tratar normalmente.
		if ( false !== strpos( $path, 'wp-login.php' ) && isset( $_GET['action'] ) && 'postpass' === $_GET['action'] && isset( $_POST['post_password'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}

		$hits_login_file = false !== strpos( $path, 'wp-login.php' )
			|| untrailingslashit( (string) wp_parse_url( site_url( 'wp-login', 'relative' ), PHP_URL_PATH ) ) === $path;

		$hits_signup = ! is_multisite() && ( false !== strpos( $path, 'wp-register.php' ) || false !== strpos( $path, 'wp-signup.php' ) );

		if ( ( $hits_login_file || $hits_signup ) && ! is_admin() ) {
			$this->blocked_login_file = true;
			// Caminho inexistente: o WordPress resolve como 404 do tema.
			$_SERVER['REQUEST_URI'] = user_trailingslashit( '/wl-404-' . wp_rand( 100000, 999999 ) );
			$pagenow                = 'index.php';
			return;
		}

		$custom_path = untrailingslashit( (string) wp_parse_url( home_url( self::slug(), 'relative' ), PHP_URL_PATH ) );
		$plain_hit   = ! $this->uses_permalinks() && isset( $_GET[ self::slug() ] ) && '' === $_GET[ self::slug() ]; // phpcs:ignore WordPress.Security.NonceVerification

		if ( $path === $custom_path || $plain_hit ) {
			$pagenow = 'wp-login.php';
		}
	}

	public function handle_request() {
		global $pagenow;

		// /wp-admin para quem não está logado: 404. AJAX, cron e admin-post continuam funcionando.
		if (
			is_admin()
			&& ! is_user_logged_in()
			&& ! wp_doing_ajax()
			&& ! wp_doing_cron()
			&& 'admin-post.php' !== $pagenow
			&& ! ( defined( 'WP_CLI' ) && WP_CLI )
		) {
			$this->render_404();
		}

		if ( $this->blocked_login_file ) {
			$this->render_404();
		}

		if ( 'wp-login.php' !== $pagenow ) {
			return;
		}

		// Normaliza a barra final para evitar conteúdo duplicado.
		$raw_path = (string) wp_parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		if ( $this->uses_permalinks() && user_trailingslashit( $raw_path ) !== $raw_path ) {
			$query = isset( $_SERVER['QUERY_STRING'] ) && '' !== $_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			wp_safe_redirect( $this->login_url() . $query );
			exit;
		}

		// Logado e sem ação específica: vai direto para o painel.
		if ( is_user_logged_in() && ! isset( $_REQUEST['action'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			wp_safe_redirect( admin_url() );
			exit;
		}

		// Variáveis que o wp-login.php espera no escopo global.
		global $error, $interim_login, $action, $user_login;

		require_once ABSPATH . 'wp-login.php';
		exit;
	}

	private function render_404() {
		global $pagenow, $wp_query;

		$pagenow = 'index.php';
		nocache_headers();

		if ( is_admin() ) {
			// No contexto do painel o tema não carrega bem. Redireciona para um 404 do site.
			wp_safe_redirect( home_url( user_trailingslashit( 'wl-404' ) ), 302 );
			exit;
		}

		if ( ! defined( 'WP_USE_THEMES' ) ) {
			define( 'WP_USE_THEMES', true );
		}

		wp();
		if ( $wp_query instanceof WP_Query && ! $wp_query->is_404() ) {
			$wp_query->set_404();
		}
		status_header( 404 );

		require_once ABSPATH . WPINC . '/template-loader.php';
		exit;
	}

	/* ------------------------------------------------------------------ */
	/* Reescrita de URLs                                                   */
	/* ------------------------------------------------------------------ */

	public function filter_site_url( $url, $path, $scheme, $blog_id ) {
		return $this->rewrite_login_url( $url, $scheme );
	}

	public function filter_network_site_url( $url, $path, $scheme ) {
		return $this->rewrite_login_url( $url, $scheme );
	}

	public function filter_wp_redirect( $location, $status ) {
		return $this->rewrite_login_url( $location );
	}

	public function filter_login_url( $login_url, $redirect, $force_reauth ) {
		return $this->rewrite_login_url( $login_url );
	}

	private function rewrite_login_url( $url, $scheme = null ) {
		if ( ! is_string( $url ) || false === strpos( $url, 'wp-login.php' ) ) {
			return $url;
		}

		// O formulário de post com senha continua no endereço padrão para não expor o novo.
		if ( false !== strpos( $url, 'wp-login.php?action=postpass' ) ) {
			return $url;
		}

		if ( is_ssl() ) {
			$scheme = 'https';
		}

		$parts = explode( '?', $url, 2 );
		$new   = $this->login_url( $scheme );

		if ( isset( $parts[1] ) && '' !== $parts[1] ) {
			parse_str( $parts[1], $args );
			if ( isset( $args['login'] ) ) {
				$args['login'] = rawurlencode( $args['login'] );
			}
			$new = add_query_arg( $args, $new );
		}

		return $new;
	}

	/* ------------------------------------------------------------------ */
	/* Configuração (Configurações > Geral)                                */
	/* ------------------------------------------------------------------ */

	public function register_settings() {
		register_setting(
			'general',
			self::OPTION,
			array(
				'type'              => 'string',
				'sanitize_callback' => array( $this, 'sanitize_slug' ),
				'default'           => self::DEFAULT_SLUG,
			)
		);

		add_settings_section(
			'wl_login_guard',
			__( 'WL Login Guard', 'wl-login-guard' ),
			array( $this, 'section_intro' ),
			'general'
		);

		add_settings_field(
			self::OPTION,
			'<label for="' . esc_attr( self::OPTION ) . '">' . esc_html__( 'Endereço de login', 'wl-login-guard' ) . '</label>',
			array( $this, 'field_slug' ),
			'general',
			'wl_login_guard'
		);
	}

	public function section_intro() {
		echo '<p>' . esc_html__( 'Quem não está logado e abre /wp-admin ou wp-login.php recebe a página 404 do site.', 'wl-login-guard' ) . '</p>';
	}

	public function field_slug() {
		$locked = defined( 'WL_LOGIN_SLUG' ) && WL_LOGIN_SLUG;
		printf(
			'<code>%1$s</code> <input type="text" id="%2$s" name="%2$s" value="%3$s" class="regular-text" %4$s> <code>/</code>',
			esc_html( trailingslashit( home_url() ) ),
			esc_attr( self::OPTION ),
			esc_attr( self::slug() ),
			$locked ? 'disabled' : ''
		);
		echo '<p class="description">';
		if ( $locked ) {
			esc_html_e( 'Definido pela constante WL_LOGIN_SLUG no wp-config.php.', 'wl-login-guard' );
		} else {
			esc_html_e( 'Salve este endereço nos favoritos. Letras minúsculas, números e hífen.', 'wl-login-guard' );
		}
		echo '</p>';
	}

	public function sanitize_slug( $value ) {
		$slug = sanitize_title( (string) $value );

		if ( '' === $slug || in_array( $slug, self::RESERVED, true ) ) {
			add_settings_error( self::OPTION, 'wl_login_guard_reserved', __( 'Esse endereço de login não pode ser usado. O anterior foi mantido.', 'wl-login-guard' ) );
			return self::slug();
		}

		if ( get_page_by_path( $slug, OBJECT, array( 'page', 'post' ) ) ) {
			add_settings_error( self::OPTION, 'wl_login_guard_conflict', __( 'Já existe uma página ou post com esse endereço. O anterior foi mantido.', 'wl-login-guard' ) );
			return self::slug();
		}

		return $slug;
	}

	public function admin_notices() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$screen = get_current_screen();
		$show   = get_transient( 'wl_login_guard_activated' )
			|| ( $screen && 'options-general' === $screen->id && isset( $_GET['settings-updated'] ) ); // phpcs:ignore WordPress.Security.NonceVerification

		if ( ! $show ) {
			return;
		}

		delete_transient( 'wl_login_guard_activated' );

		printf(
			'<div class="notice notice-success is-dismissible"><p>%1$s <strong><a href="%2$s">%2$s</a></strong></p></div>',
			esc_html__( 'WL Login Guard ativo. Seu endereço de login é:', 'wl-login-guard' ),
			esc_url( $this->login_url() )
		);
	}

	public function action_links( $links ) {
		$settings = '<a href="' . esc_url( admin_url( 'options-general.php#' . self::OPTION ) ) . '">' . esc_html__( 'Configurações', 'wl-login-guard' ) . '</a>';
		array_unshift( $links, $settings );
		return $links;
	}

	public static function activate() {
		if ( false === get_option( self::OPTION ) ) {
			add_option( self::OPTION, self::DEFAULT_SLUG );
		}
		set_transient( 'wl_login_guard_activated', 1, 60 );
	}
}

register_activation_hook( __FILE__, array( 'WL_Login_Guard', 'activate' ) );

if ( ! ( defined( 'WL_LOGIN_GUARD_DISABLE' ) && WL_LOGIN_GUARD_DISABLE ) ) {
	new WL_Login_Guard();
}
