=== WL Login Guard ===
Contributors: wisionarylab
Tags: login, segurança, wp-admin, wp-login
Requires at least: 5.8
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPL-2.0-or-later

Troca o endereço de login do WordPress e esconde wp-login.php e /wp-admin de quem não está logado.

== Descrição ==

Plugin da Wisionary Lab.

* Login em /wl-admin (configurável em Configurações > Geral).
* /wp-admin, /wp-login.php, /wp-register.php e /wp-signup.php mostram a página 404 do site para quem não está logado.
* Links de sair, recuperar senha, redefinir senha e e-mails do WordPress passam a usar o novo endereço.
* /login, /admin e /dashboard deixam de redirecionar para o login padrão.
* admin-ajax.php, admin-post.php, WP-Cron e a API REST continuam funcionando.
* Usuário logado que abre o endereço de login vai direto para o painel.

== Instalação ==

1. Plugins > Adicionar novo > Enviar plugin. Envie o arquivo wl-login-guard.zip.
2. Ative. O aviso no topo mostra o novo endereço. Salve nos favoritos.
3. Para trocar o endereço: Configurações > Geral, seção WL Login Guard.

== Se perder o acesso ==

Escolha uma das opções:

* Pelo cPanel (Gerenciador de Arquivos) ou FTP, renomeie a pasta wp-content/plugins/wl-login-guard. O login volta a ser /wp-admin.
* No wp-config.php, adicione define( 'WL_LOGIN_GUARD_DISABLE', true ); para desligar o plugin.
* No wp-config.php, adicione define( 'WL_LOGIN_SLUG', 'outro-endereco' ); para forçar um endereço.

== Observações ==

* Se o site usa cache de página (LiteSpeed, cache da hospedagem, Cloudflare), limpe o cache depois de ativar e exclua o endereço de login do cache.
* Não use junto com outro plugin que também esconde o login (WPS Hide Login, função Hide Backend do Solid Security).
* Feito para sites WordPress simples. Multisite não foi testado.

== Changelog ==

= 1.0.0 =
* Primeira versão.
