<?php
/**
 * Remove a configuração do WL Login Guard ao excluir o plugin.
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

delete_option( 'wl_login_guard_slug' );
delete_option( 'wl_login_guard_block_xmlrpc' );
delete_option( 'wl_login_guard_hide_users' );
delete_transient( 'wl_login_guard_activated' );
