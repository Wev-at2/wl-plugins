=== WL Cookie Banner ===
Contributors: wisionarylab
Tags: cookies, lgpd, consentimento, consent mode, site kit
Requires at least: 6.0
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPL-2.0-or-later

Aviso de cookies com aceite, recusa e escolha por categoria. Integra com a WP Consent API e com o modo de consentimento do Google.

== Descrição ==

Plugin da Wisionary Lab.

* Banner com Aceitar, Recusar e Escolher. Recusar tem o mesmo peso visual que Aceitar.
* Categorias: Necessários (sempre ativos), Estatísticas, Marketing e Preferências. Mostre só as que o site usa.
* Modo de consentimento do Google: tudo começa negado para todos os visitantes, inclusive no Brasil, até a pessoa escolher.
* Integra com a WP Consent API. O Site Kit by Google respeita a escolha sem nenhuma configuração extra.
* Retirar a permissão de Estatísticas apaga os cookies do Google Analytics.
* Botão pequeno no canto para rever a escolha, ou o atalho [wl_cookies] e links para #wl-cookies.
* Aparência escura ou clara e cor de destaque configuráveis.
* Funciona com cache de página: o banner é decidido no navegador.

== Instalação ==

1. Instale e ative a WP Consent API (plugin oficial, gratuito).
2. Plugins > Adicionar novo > Enviar plugin. Envie wl-cookie-banner.zip e ative.
3. Configurações > Cookies: revise o texto e marque só as categorias que o site usa.
4. Publique a Política de Privacidade e defina a página em Configurações > Privacidade. O link entra no banner sozinho.

== Para desenvolvedores ==

* Cookie: wl_cookie_consent, JSON com r (revisão), s (estatísticas), m (marketing), p (preferências) e t (data).
* Evento: document.addEventListener('wl:cookie-consent', e => e.detail).
* JavaScript: WLCookies.open() abre as preferências. WLCookies.get() devolve a escolha atual ou null.

== Changelog ==

= 1.0.0 =
* Primeira versão.
