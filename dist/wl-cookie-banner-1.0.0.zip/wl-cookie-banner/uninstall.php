<?php
/**
 * Remove a configuração do WL Cookie Banner ao excluir o plugin.
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

delete_option( 'wl_cookie_banner' );
